export {};

declare global {
    interface TelegramWebAppUser {
        id: number;
        first_name: string;
        last_name?: string;
        username?: string;
        language_code?: string;
    }

    interface TelegramWebApp {
        initData: string;
        initDataUnsafe?: {
            user?: TelegramWebAppUser;
        };
        expand?: () => void;
        ready?: () => void;
        openLink?: (url: string) => void;       // 👈 добавить
        openInvoice?: (slug: string) => void;   // 👈 если используешь
        // add other methods if needed
    }

    interface Window {
        Telegram?: {
            WebApp?: TelegramWebApp;
        };
    }
}
