export const mockInitData = {
    id: 1113418229,
    first_name: 'M. S.',
    last_name: '',
    username: 'nikita_sy',
};