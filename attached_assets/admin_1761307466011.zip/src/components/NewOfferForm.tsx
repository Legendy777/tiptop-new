import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import type { AppDispatch, RootState } from "../store/store.ts";
import { fetchGames } from "../store/features/gamesSlice.ts";
import { addOffer } from "../store/features/offersSlice.ts";

const NewOfferForm: React.FC = () => {
    const games = useSelector((state: RootState) => state.games.games);
    const dispatch = useDispatch<AppDispatch>();

    const [gameId, setGameId] = useState<number>(0);
    const [title, setTitle] = useState('');
    const [imageUrl, setImageUrl] = useState('');
    const [priceRUB, setPriceRUB] = useState<string>('');
    const [priceUSDT, setPriceUSDT] = useState<string>('');
    const [isEnabled, setIsEnabled] = useState(true);

    useEffect(() => {
        dispatch(fetchGames());
    }, [dispatch]);

    useEffect(() => {
        if (games.length > 0 && gameId === 0) {
            setGameId(games[0]._id);
        }
    }, [games, gameId]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!gameId) return;

        const offer = {
            gameId,
            title,
            imageUrl,
            priceRUB: parseFloat(priceRUB),
            priceUSDT: parseFloat(priceUSDT),
            isEnabled,
        };

        await dispatch(addOffer(offer));

        setTitle('');
        setImageUrl('');
        setPriceRUB('');
        setPriceUSDT('');
        setIsEnabled(true);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-2 max-w-md p-4 rounded">
            <select
                value={gameId}
                onChange={(e) => setGameId(Number(e.target.value))}
                required
                className="w-full p-2 border"
            >
                {games.map((game) => (
                    <option key={game._id} value={game._id} className="text-black">
                        {game.title}
                    </option>
                ))}
            </select>

            <input
                type="text"
                placeholder="Title"
                value={title}
                required
                onChange={(e) => setTitle(e.target.value)}
                className="w-full p-2 border"
            />

            <input
                type="url"
                placeholder="Image URL"
                value={imageUrl}
                required
                onChange={(e) => setImageUrl(e.target.value)}
                className="w-full p-2 border"
            />

            <input
                type="number"
                step="0.01"
                placeholder="Price RUB"
                value={priceRUB}
                required
                min={0}
                onChange={(e) => setPriceRUB(e.target.value)}
                className="w-full p-2 border"
            />

            <input
                type="number"
                step="0.01"
                placeholder="Price USDT"
                value={priceUSDT}
                required
                min={0}
                onChange={(e) => setPriceUSDT(e.target.value)}
                className="w-full p-2 border"
            />

            <label className="inline-flex items-center space-x-2">
                <input
                    type="checkbox"
                    checked={isEnabled}
                    onChange={() => setIsEnabled(!isEnabled)}
                />
                <span>Is Enabled</span>
            </label>

            <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
                Add Offer
            </button>
        </form>
    );
};

export default NewOfferForm;
